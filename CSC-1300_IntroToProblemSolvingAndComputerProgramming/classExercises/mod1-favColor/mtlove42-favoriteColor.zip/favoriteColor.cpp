#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
    string favoriteColor = "Green";
    cout << "This is my favorite color: " << favoriteColor << endl;
}
